Spring 2015-CS101 Project.

Project Title: OPTIMISED TIME-TABLE GENERATOR

Team ID/Group Number: 371


Group CUSE  
R.Basuhi, 			140010037 
Yashaswini K Murthy,	 	140010054 
Shachi Shailesh Deshpande, 	140110047 

Instructions to set-up the project:


Install Code::Blocks IDE on you system. (For help, visit http://wiki.codeblocks.org/index.phptitle=Installing_Code::Blocks)

Download the project application from Moodle. It is available as a compressed folder. You'll have to decompress it.

Open the folder and check if Optimised_TimeTable_Generator_v1.cpp is present.

Run Code::Blocks. Open Optimised_TimeTable_Generator_v1.cpp in it, build and run the program. 

Voila, it should work!


Youtube link for the online tutorial on how to use this application: https://www.youtube.com/watch?v=xyACrW8kcXY&feature=youtu.be



